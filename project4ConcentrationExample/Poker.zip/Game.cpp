#include <iostream>
#include <iomanip>
#include <sstream>
#include <cstdlib>
#include <ctype.h>
#include <algorithm>
#include <string>
#include <string.h>
#include <sys/time.h>
#include "Deck.h"
#include "Hand.h"
#include "Game.h"
using namespace std;


// ==============================================================================
Game::Game() {
  shoe.initPoker();
}

// ==============================================================================
void Game::initGame() {
}

// ==============================================================================
void Game::initDeal() {
   Card C;
   Hand H;

   PlayerHand = H;
   OpponentHand = H;

   // Draw first cards for each player
   C = shoe.DrawCard();
   PlayerHand.Append(C);
   C = shoe.DrawCard();
   OpponentHand.Append(C);
   showHandsNoHole();
   
   // Draw second cards for each player
   C = shoe.DrawCard();
   PlayerHand.Append(C);
   C = shoe.DrawCard();
   OpponentHand.Append(C);
   showHandsNoHole();

   // Draw third cards for each player
   C = shoe.DrawCard();
   PlayerHand.Append(C);
   C = shoe.DrawCard();
   OpponentHand.Append(C);
   showHandsNoHole();

   // Draw fourth cards for each player
   C = shoe.DrawCard();
   PlayerHand.Append(C);
   C = shoe.DrawCard();
   OpponentHand.Append(C);
   showHandsNoHole();

   // Draw fifth cards for each player
   C = shoe.DrawCard();
   PlayerHand.Append(C);
   C = shoe.DrawCard();
   OpponentHand.Append(C);
   showHandsNoHole();
}

// ==============================================================================
void Game::showHands() {
   
   cout << "=================================================================" ;
   cout << endl;

   cout << "Opponnent's Hand:  ";
   OpponentHand.Display();
   cout << endl;
   cout << "Your Hand:         "; 
   PlayerHand.Display();
   cout << endl;
}

// ==============================================================================
void Game::showHandsNoHole() {

   cout << "=================================================================" ;
   cout << endl;

   cout << "Opponnent's Hand:  ";
   OpponentHand.DisplayNoHole();
   cout << endl;
   cout << "Your Hand:         "; 
   PlayerHand.Display();
   cout << endl;
}
   
// ==============================================================================
int Game::PromptDiscard(int card_num) {
   char ch;
   string answer;
   int Cardnum=0;

   do {
      if (card_num == 1) {
         cout << "Which card do you wish to discard 1st? ";
      }
      else if (card_num == 2) {
         cout << "Which card do you wish to discard 2nd? ";
      }
      else if (card_num == 3) {
         cout << "Which card do you wish to discard 3rd? ";
      }
      cin >> ch;
      if (isdigit((int)ch)) {
         answer = ch; 
         stringstream ss(answer);
         ss >> Cardnum;
      }

      if (isdigit((int) ch) && ((Cardnum <= 0) || (Cardnum >= 6))) { 
         cout << endl << "That was not a valid card number." << endl;
      }

   } while (isdigit((int) ch) && ((Cardnum <= 0) || (Cardnum >= 6))); 
   return Cardnum;
}

// ==============================================================================
void Game::reverseSort(int &C1, int &C2, int &C3) {
   int temp1;
   int temp2;
   int temp3;

   if ((C1 > C2) && (C2 > C3)) {
      // nothing to do
      return;
   }
   else if ((C1 > C3) && (C3 > C2)) {
      // change 2 and 3
      temp2 = C2;
      temp3 = C3;
      C2 = temp3;
      C3 = temp2;
   }
   else if ((C2 > C1) && (C1 > C3)) {
      // change 1 and 2
      temp1 = C1;
      temp2 = C2;
      C1 = temp2;
      C2 = temp1;
   }
   else if ((C2 > C3) && (C3 > C1)) {
      // change 1 and 2 and 3
      temp1 = C1;
      temp2 = C2;
      temp3 = C3;
      C1 = temp2;
      C2 = temp3;
      C3 = temp1;
   }
   else if ((C3 > C1) && (C1 > C2)) {
      // change 1 and 2 and 3
      temp1 = C1;
      temp2 = C2;
      temp3 = C3;
      C1 = temp3;
      C2 = temp1;
      C3 = temp2;
   }
   else if ((C3 > C2) && (C2 > C1)) {
      // change 1 and 3
//cout << "foof" << endl;
      temp1 = C1;
      temp3 = C3;
      C1 = temp3;
      C3 = temp1;
   }
} 
   
// ==============================================================================
void Game::PlayerTurn() {
   char answer = ' ';
   Card C;
   int count = 0;
   int pos = 0;
   CRank PlayerRank;
   CRank OpponentRank;
   bool flag1 = true;
   bool flag2 = true;

   int Card1 = 0;
   int Card2 = 0;
   int Card3 = 0;

   PlayerHand.sortHand();
   showHandsNoHole();
   cout << "Cards are numbered 1 to 5 from left to right.  ";
   cout << "Please identify, " << endl;
   cout << "by position number, up to 3 card which you would like to discard" << endl;

   count = 0;
   Card1 = PromptDiscard(1);
   if (Card1 == 0) {
      Card2 = 0;
      Card3 = 0;
   }
   else {
      count++;
      do {
         Card2 = PromptDiscard(2);
         if (Card2 == Card1) {
            cout << "You can't select the same card twice" << endl;
         }
      } while (Card2 == Card1);
      if (Card2 == 0) {
         Card3 = 0;
      }
      else {
         count++;
         do {
            Card3 = PromptDiscard(3);
            if ((Card3 == Card2) || (Card3 == Card1)) {
               cout << "You can't select the same card twice" << endl;
            }
         } while ((Card3 == Card2) || (Card3 == Card1));
         if (Card3 == 0) {
         }
         else {
            count++;
         }
      }
   }

   reverseSort(Card1, Card2, Card3);

   cout << "You have elected to discard and draw " << count << " cards: ";
   if (count >= 1) {
      cout << Card1 << " ";
   }
   if (count >= 2) {
      cout << Card2 << " ";
   }
   if (count >= 3) {
      cout << Card3;
   }
   cout << endl;

   if (Card1 > 0) {
      Card1--;
      PlayerHand.DeleteCard(Card1);
   }
   if (Card2 > 0) {
      Card2--;
      PlayerHand.DeleteCard(Card2);
   }
   if (Card3 > 0) {
      Card3--;
      PlayerHand.DeleteCard(Card3);
   }
      
   showHandsNoHole();
   for (int j = 0; j < count; j++) {
       C = shoe.DrawCard();
       PlayerHand.Append(C);
   }
   PlayerHand.sortHand();
   showHandsNoHole();
}

void Game::OppDrawCards(int cardnum1, int cardnum2 = -1, int cardnum3 = -1) {
   Card C;
   int temp1, temp2, temp3;

   if ((cardnum1 > cardnum3) && (cardnum3 > cardnum2)) {
      temp2 = cardnum2;
      temp3 = cardnum3;
      cardnum2 = temp3;
      cardnum3 = temp2;
   }
   else if ((cardnum2 > cardnum1) && (cardnum1 > cardnum3)) {
      temp1 = cardnum1;
      temp2 = cardnum2;
      cardnum1 = temp2;
      cardnum2 = temp1;
   }
   else if ((cardnum2 > cardnum3) && (cardnum3 > cardnum1)) {
      temp1 = cardnum1;
      temp2 = cardnum2;
      temp3 = cardnum3;
      cardnum1 = temp2;
      cardnum2 = temp3;
      cardnum3 = temp1;
   }
   else if ((cardnum3 > cardnum1) && (cardnum1 > cardnum2)) {
      temp1 = cardnum1;
      temp2 = cardnum2;
      temp3 = cardnum3;
      cardnum1 = temp3;
      cardnum2 = temp1;
      cardnum3 = temp2;
   }
   else if ((cardnum3 > cardnum2) && (cardnum2 > cardnum1)) {
      temp1 = cardnum1;
      temp2 = cardnum2;
      temp3 = cardnum3;
      cardnum1 = temp3;
      cardnum2 = temp2;
      cardnum3 = temp1;
   }

   if (cardnum3 > 0) {
      cout << "Opponent has elected to discard and draw 3 cards: "; 
      cout << cardnum1 << " " << cardnum2 << " " << cardnum3 << endl;
   }
   else if (cardnum2 > 0) {
      cout << "Opponent has elected to discard and draw 2 cards: "; 
      cout << cardnum1 << " " << cardnum2 << endl;
   }
   else {
      cout << "Opponent has elected to discard and draw 1 card: "; 
      cout << cardnum1 << endl;
   }

   // delete the selected cards from the hand
   OpponentHand.DeleteCard(cardnum1 - 1);
   if (cardnum2 > 0) {
      OpponentHand.DeleteCard(cardnum2 - 1);
   }
   if (cardnum3 > 0) {
      OpponentHand.DeleteCard(cardnum3 - 1);
   }

   showHands();

   // replace the deleted cards by drawing from the shoe
   C = shoe.DrawCard();
   OpponentHand.Append(C);
   if (cardnum2 > 0) {
      C = shoe.DrawCard();
      OpponentHand.Append(C);
   }
   if (cardnum3 > 0) {
      C = shoe.DrawCard();
      OpponentHand.Append(C);
   }
   
} 
   

void Game::HandleFourKind() {
   int cardnum;
   int cardvalue;

   Card Card1 = OpponentHand.getCard(0);
   Card Card2 = OpponentHand.getCard(1);
   Card Card3 = OpponentHand.getCard(2);
   Card Card4 = OpponentHand.getCard(3);
   Card Card5 = OpponentHand.getCard(4);

   int val1 = Card1.getValue();
   int val2 = Card2.getValue();
   int val3 = Card3.getValue();
   int val4 = Card4.getValue();
   int val5 = Card5.getValue();

   // find the 5th card not part of the FourKind
   if ((val1 == val2) && (val2 == val3) && (val3 == val4)) {
      cardnum = 5;
      cardvalue = val5;
   }
   else if ((val1 == val2) && (val2 == val3) && (val3 == val5)) {
      cardnum = 4;
      cardvalue = val4;
   }
   else if ((val1 == val2) && (val2 == val4) && (val4 == val5)) {
      cardnum = 3;
      cardvalue = val3;
   }
   else if ((val1 == val3) && (val3 == val4) && (val4 == val5)) {
      cardnum = 2;
      cardvalue = val2;
   }
   else if ((val2 == val3) && (val3 == val4) && (val4 == val5)) {
      cardnum = 1;
      cardvalue = val1;
   }

   // if value < 11 then discard and draw
   if (cardvalue < 11) {
      OppDrawCards(cardnum);
      cout << "Opponent has elected to discard and draw 1 card: ";
      cout << (cardnum+1) << endl;
   }
   else {
      cout << "Opponent has elected to stand with his cards." << endl;
   }
}

void Game::HandleThreeKind() {
   int cardnum1;
   int cardnum2;
   int cardvalue1;
   int cardvalue2;

   Card Card1 = OpponentHand.getCard(0);
   Card Card2 = OpponentHand.getCard(1);
   Card Card3 = OpponentHand.getCard(2);
   Card Card4 = OpponentHand.getCard(3);
   Card Card5 = OpponentHand.getCard(4);

   int val1 = Card1.getValue();
   int val2 = Card2.getValue();
   int val3 = Card3.getValue();
   int val4 = Card4.getValue();
   int val5 = Card5.getValue();

   // find the two cards not part of ThreeKind
   if ((val1 == val2) && (val2 == val3))  {
      cardnum1 = 4;
      cardvalue1 = val4;
      cardnum2 = 5;
      cardvalue2 = val5;
   }
   else if ((val1 == val2) && (val2 == val4))  {
      cardnum1 = 3;
      cardvalue1 = val3;
      cardnum2 = 5;
      cardvalue2 = val5;
   }
   else if ((val1 == val2) && (val2 == val5))  {
      cardnum1 = 3;
      cardvalue1 = val3;
      cardnum2 = 4;
      cardvalue2 = val4;
   }
   else if ((val1 == val3) && (val3 == val4))  {
      cardnum1 = 2;
      cardvalue1 = val2;
      cardnum2 = 5;
      cardvalue2 = val5;
   }
   else if ((val1 == val3) && (val3 == val5))  {
      cardnum1 = 2;
      cardvalue1 = val2;
      cardnum2 = 4;
      cardvalue2 = val4;
   }
   else if ((val1 == val4) && (val4 == val5))  {
      cardnum1 = 2;
      cardvalue1 = val2;
      cardnum2 = 3;
      cardvalue2 = val3;
   }
   else if ((val2 == val3) && (val3 == val4))  {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 5;
      cardvalue2 = val5;
   }
   else if ((val2 == val3) && (val3 == val5))  {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 4;
      cardvalue2 = val4;
   }
   else if ((val2 == val4) && (val4 == val5))  {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 3;
      cardvalue2 = val3;
   }
   else if ((val3 == val4) && (val4 == val5))  {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 2;
      cardvalue2 = val2;
   }

   // discard and draw one or both cards 
   if (cardvalue1 > cardvalue2) {
      if (cardvalue1 < 11) {
         OppDrawCards(cardnum1, cardnum2);
         cout << "Opponent has elected to discard and draw 2 cards: ";
         cout << (cardnum1+1) << " " << (cardnum2+1) << endl;
      }
      else {
         OppDrawCards(cardnum2);
         cout << "Opponent has elected to discard and draw 1 card: ";
         cout << (cardnum2+1) << endl;
      }
   }
   else {
      if (cardvalue2 < 11) {
         OppDrawCards(cardnum2, cardnum1);
         cout << "Opponent has elected to discard and draw 2 cards: ";
         cout << (cardnum2+1) << " " << (cardnum1+1) << endl;
      }
      else {
         OppDrawCards(cardnum1);
         cout << "Opponent has elected to discard and draw 1 card: ";
         cout << (cardnum1+1) << endl;
      }
   }
}

void Game::HandleTwoPair() {
   int cardnum;
   int cardval;

   Card Card1 = OpponentHand.getCard(0);
   Card Card2 = OpponentHand.getCard(1);
   Card Card3 = OpponentHand.getCard(2);
   Card Card4 = OpponentHand.getCard(3);
   Card Card5 = OpponentHand.getCard(4);

   int val1 = Card1.getValue();
   int val2 = Card2.getValue();
   int val3 = Card3.getValue();
   int val4 = Card4.getValue();
   int val5 = Card5.getValue();

   // find the card not part of TwoPair
   if ((val1 == val2) && (val3 == val4)) {
      cardnum = 5;
      cardval = val5;
   }
   else if ((val1 == val2) && (val3 == val5)) {
      cardnum = 4;
      cardval = val4;
   }
   else if ((val1 == val2) && (val4 == val5)) {
      cardnum = 3;
      cardval = val3;
   }
   else if ((val1 == val3) && (val2 == val4)) {
      cardnum = 5;
      cardval = val5;
   }
   else if ((val1 == val3) && (val2 == val5)) {
      cardnum = 4;
      cardval = val4;
   }
   else if ((val1 == val3) && (val4 == val5)) {
      cardnum = 2;
      cardval = val2;
   }
   else if ((val1 == val4) && (val2 == val3)) {
      cardnum = 5;
      cardval = val5;
   }
   else if ((val1 == val4) && (val2 == val5)) {
      cardnum = 3;
      cardval = val3;
   }
   else if ((val1 == val4) && (val3 == val5)) {
      cardnum = 2;
      cardval = val2;
   }
   else if ((val1 == val5) && (val2 == val3)) {
      cardnum = 4;
      cardval = val4;
   }
   else if ((val1 == val5) && (val2 == val4)) {
      cardnum = 3;
      cardval = val3;
   }
   else if ((val1 == val5) && (val3 == val4)) {
      cardnum = 2;
      cardval = val2;
   }
 
   if (cardval < 11) {
      // discard the card an draw another
      OppDrawCards(cardnum);
      cout << "Opponent has elected to discard and draw 1 card: ";
      cout << (cardnum+1) << endl;
   }
}

void Game::HandlePair() {
   int cardnum1;
   int cardnum2;
   int cardnum3;
   int cardvalue1;
   int cardvalue2;
   int cardvalue3;

   Card Card1 = OpponentHand.getCard(0);
   Card Card2 = OpponentHand.getCard(1);
   Card Card3 = OpponentHand.getCard(2);
   Card Card4 = OpponentHand.getCard(3);
   Card Card5 = OpponentHand.getCard(4);

   int val1 = Card1.getValue();
   int val2 = Card2.getValue();
   int val3 = Card3.getValue();
   int val4 = Card4.getValue();
   int val5 = Card5.getValue();

   // find the three cards not part of the Pair
   if (val1 == val2) {
      cardnum1 = 3;
      cardvalue1 = val3;
      cardnum2 = 4;
      cardvalue2 = val4;
      cardnum3 = 5;
      cardvalue3 = val5;
   }
   else if (val1 == val3) {
      cardnum1 = 2;
      cardvalue1 = val2;
      cardnum2 = 4;
      cardvalue2 = val4;
      cardnum3 = 5;
      cardvalue3 = val5;
   }
   else if (val1 == val4) {
      cardnum1 = 2;
      cardvalue1 = val2;
      cardnum2 = 3;
      cardvalue2 = val3;
      cardnum3 = 5;
      cardvalue3 = val5;
   }
   else if (val1 == val5) {
      cardnum1 = 2;
      cardvalue1 = val2;
      cardnum2 = 3;
      cardvalue2 = val3;
      cardnum3 = 4;
      cardvalue3 = val4;
   }
   else if (val2 == val3) {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 4;
      cardvalue2 = val4;
      cardnum3 = 5;
      cardvalue3 = val5;
   }
   else if (val2 == val4) {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 3;
      cardvalue2 = val3;
      cardnum3 = 5;
      cardvalue3 = val5;
   }
   else if (val2 == val5) {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 3;
      cardvalue2 = val3;
      cardnum3 = 4;
      cardvalue3 = val4;
   }
   else if (val3 == val4) {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 2;
      cardvalue2 = val2;
      cardnum3 = 5;
      cardvalue3 = val5;
   }
   else if (val3 == val5) {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 2;
      cardvalue2 = val2;
      cardnum3 = 4;
      cardvalue3 = val4;
   }
   else if (val4 == val5) {
      cardnum1 = 1;
      cardvalue1 = val1;
      cardnum2 = 2;
      cardvalue2 = val2;
      cardnum3 = 3;
      cardvalue3 = val3;
   }

   // discard the three cards and draw three more
   if ((cardvalue1 > cardvalue2) && (cardvalue2 > cardvalue3)) {
      if (cardvalue1 < 11) {
 cout << "Pair - a) draw 3 cards" << endl;
         OppDrawCards(cardnum1, cardnum2, cardnum3);
         //cout << "Opponent has elected to discard and draw 3 cards: ";
         //cout << (cardnum1+1) << " " << (cardnum2+1) << " " << (cardnum3+1) << endl;
      }
      else {
 cout << "Pair - b) draw 2 cards" << endl;
         OppDrawCards(cardnum2, cardnum3);
         //cout << "Opponent has elected to discard and draw 2 cards: ";
         //cout << (cardnum2+1) << " " << (cardnum3+1) << endl;
      }
   }
   if ((cardvalue1 > cardvalue3) && (cardvalue3 > cardvalue2)) {
      if (cardvalue1 < 11) {
 cout << "Pair - c) draw 3 cards" << endl;
         OppDrawCards(cardnum1, cardnum2, cardnum3);
         //cout << "Opponent has elected to discard and draw 3 cards: ";
         //cout << (cardnum1+1) << " " << (cardnum2+1) << " " << (cardnum3+1) << endl;
      }
      else {
 cout << "Pair - d) draw 2 cards" << endl;
         OppDrawCards(cardnum2, cardnum3);
         //cout << "Opponent has elected to discard and draw 2 cards: ";
         //cout << (cardnum2+1) << " " << (cardnum3+1) << endl;
      }
   }
   if ((cardvalue2 > cardvalue1) && (cardvalue1 > cardvalue3)) {
      if (cardvalue2 < 11) {
 cout << "Pair - e) draw 3 cards" << endl;
         OppDrawCards(cardnum2, cardnum1, cardnum3);
         //cout << "Opponent has elected to discard and draw 3 cards: ";
         //cout << (cardnum1+1) << " " << (cardnum2+1) << " " << (cardnum3+1) << endl;
      }
      else {
 cout << "Pair - f) draw 2 cards" << endl;
         OppDrawCards(cardnum1, cardnum3);
      }
   }
   if ((cardvalue2 > cardvalue3) && (cardvalue3 > cardvalue1)) {
      if (cardvalue2 < 11) {
 cout << "Pair - g) draw 3 cards" << endl;
         OppDrawCards(cardnum2, cardnum1, cardnum3);
      }
      else {
 cout << "Pair - h) draw 2 cards" << endl;
         OppDrawCards(cardnum1, cardnum3);
      }
   }
   if ((cardvalue3 > cardvalue1) && (cardvalue1 > cardvalue2)) {
      if (cardvalue3 < 11) {
 cout << "Pair - j) draw 3 cards" << endl;
         OppDrawCards(cardnum3, cardnum1, cardnum2);
      }
      else {
 cout << "Pair - k) draw 2 cards" << endl;
         OppDrawCards(cardnum1, cardnum2);
      }
   }
   if ((cardvalue3 > cardvalue2) && (cardvalue2 > cardvalue1)) {
      if (cardvalue3 < 11) {
 cout << "Pair - l) draw 3 cards" << endl;
         OppDrawCards(cardnum3, cardnum1, cardnum2);
      }
      else {
 cout << "Pair - m) draw 2 cards" << endl;
         OppDrawCards(cardnum1, cardnum2);
      }
   }
}

void Game::HandleHigh() {
   int cardnum1;
   int cardnum2;
   int cardnum3;
   int cardvalue1;
   int cardvalue2;
   int cardvalue3;

   Card Card1 = OpponentHand.getCard(0);
   Card Card2 = OpponentHand.getCard(1);
   Card Card3 = OpponentHand.getCard(2);
   Card Card4 = OpponentHand.getCard(3);
   Card Card5 = OpponentHand.getCard(4);

   int val1 = Card1.getValue();
   int val2 = Card2.getValue();
   int val3 = Card3.getValue();
   int val4 = Card4.getValue();
   int val5 = Card5.getValue();

   // find the three low cards and discard and draw three more
   if ((val1 > val2) && (val2 > val3) && (val2 > val4) && (val2 > val5)) {
      OppDrawCards(3, 4, 5);
   }
   else if ((val1 > val3) && (val3 > val2) && (val3 > val4) && (val3 > val5)) {
      OppDrawCards(2, 4, 5);
   }
   else if ((val1 > val4) && (val4 > val2) && (val4 > val3) && (val4 > val5)) {
      OppDrawCards(2, 3, 5);
   }
   else if ((val1 > val5) && (val5 > val2) && (val5 > val3) && (val5 > val4)) {
      OppDrawCards(2, 3, 4);
   }
   else if ((val2 > val3) && (val3 > val1) && (val3 > val4) && (val3 > val5)) {
      OppDrawCards(1, 4, 5);
   }
   else if ((val2 > val4) && (val4 > val1) && (val4 > val3) && (val4 > val5)) {
      OppDrawCards(1, 3, 5);
   }
   else if ((val2 > val5) && (val5 > val1) && (val5 > val3) && (val5 > val4)) {
      OppDrawCards(1, 3, 4);
   }
   else if ((val3 > val4) && (val4 > val1) && (val4 > val2) && (val4 > val5)) {
      OppDrawCards(1, 2, 5);
   }
   else if ((val3 > val5) && (val5 > val1) && (val5 > val2) && (val5 > val4)) {
      OppDrawCards(1, 2, 4);
   }
   else if ((val4 > val5) && (val5 > val1) && (val5 > val2) && (val5 > val3)) {
      OppDrawCards(1, 2, 3);
   }
   else if ((val2 > val1) && (val1 > val3) && (val1 > val4) && (val1 > val5)) {
      OppDrawCards(3, 4, 5);
   }
   else if ((val3 > val1) && (val1 > val2) && (val1 > val4) && (val1 > val5)) {
      OppDrawCards(2, 4, 5);
   }
   else if ((val4 > val1) && (val1 > val2) && (val1 > val3) && (val1 > val5)) {
      OppDrawCards(2, 3, 5);
   }
   else if ((val5 > val1) && (val1 > val2) && (val1 > val3) && (val1 > val4)) {
      OppDrawCards(2, 3, 4);
   }
   else if ((val3 > val2) && (val2 > val1) && (val2 > val4) && (val2 > val5)) {
      OppDrawCards(1, 4, 5);
   }
   else if ((val4 > val2) && (val2 > val1) && (val2 > val3) && (val2 > val5)) {
      OppDrawCards(1, 3, 5);
   }
   else if ((val5 > val2) && (val2 > val1) && (val2 > val3) && (val2 > val4)) {
      OppDrawCards(1, 3, 4);
   }
   else if ((val4 > val3) && (val3 > val1) && (val3 > val2) && (val3 > val5)) {
      OppDrawCards(1, 2, 5);
   }
   else if ((val5 > val3) && (val3 > val1) && (val3 > val2) && (val3 > val4)) {
      OppDrawCards(1, 2, 4);
   }
   else if ((val5 > val4) && (val4 > val1) && (val4 > val2) && (val4 > val3)) {
      OppDrawCards(1, 2, 3);
   }
}

void Game::OpponentTurn() {
   CRank myRank;

   OpponentHand.sortHand();
   showHands();
   myRank = OpponentHand.ComputePokerRank();

   cout << "Opponent's Rank: " << myRank << endl;
   if (myRank == RoyalFlush) {
       // do nothing - these hands can't easily be improved upon
       cout << "a Opponent has elected to stand." <<endl;
   }
   else if (myRank == StraightFlush) {
       // do nothing - these hands can't easily be improved upon
       cout << "b Opponent has elected to stand." <<endl;
   }
   else if (myRank == FullHouse) { 
       // do nothing - these hands can't easily be improved upon
       cout << "c Opponent has elected to stand." <<endl;
   }
   else if (myRank == Flush) { 
       // do nothing - these hands can't easily be improved upon
       cout << "d Opponent has elected to stand." <<endl;
   }
   else if (myRank == Straight) {
       // do nothing - these hands can't easily be improved upon
       cout << "e Opponent has elected to stand." <<endl;
   }


   else if (myRank == FourKind) {
       cout << "Opponent has Four of a Kind." <<endl;
       HandleFourKind();
   }
   else if (myRank == ThreeKind) {
       cout << "Opponent has Three of a Kind." <<endl;
       HandleThreeKind();
   }
   else if (myRank == TwoPair) {
       cout << "Opponent has Two Pair." <<endl;
       HandleTwoPair();
   }
   else if (myRank == Pair) {
       cout << "Opponent has a Pair." <<endl;
       HandlePair();
   }
   else if (myRank == High) {
       cout << "Opponent has a High card." <<endl;
       HandleHigh();
   }
   else {
       cout << "Hand not recognized - no action taken" << endl;
   }

   showHands();
}

void sortCards(Card cards[]) {
   for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 5 - i - 1; j++) {
         if ((cards[j]).getValue() < (cards[j+1]).getValue() ) {
            Card temp;
            temp = cards[j];
            cards[j] = cards[j+1];
            cards[j+1] = temp;
         }
      }
   }
}

void Game::BreakTie() {
   CRank PRank;
   int Pcardnum1, Pcardnum2, Pcardnum3, Pcardnum4, Pcardnum5;
   int Pcardvalue1, Pcardvalue2, Pcardvalue3, Pcardvalue4, Pcardvalue5;
   int Ocardnum1, Ocardnum2, Ocardnum3, Ocardnum4, Ocardnum5;
   int Ocardvalue1, Ocardvalue2, Ocardvalue3, Ocardvalue4, Ocardvalue5;

   Card PCards[5];
   int  Pvals[5];
   Card OCards[5];
   int  Ovals[5];
   for (int i = 0; i<5;i++) {
      PCards[i] = PlayerHand.getCard(i);
      Pvals[i] = PCards[i].getValue();
      OCards[i] = OpponentHand.getCard(i);
      Ovals[i] = OCards[i].getValue();
   }

   sortCards(PCards);
   sortCards(OCards);

   PRank = PlayerHand.ComputePokerRank();

   if(PRank == RoyalFlush) {
      cout << "Neither hand wins" << endl;
   }
   else if (PRank == StraightFlush) {
      // high card wins the hand

      int PHighCard = (Pvals[0]);
      int OHighCard = (Ovals[0]); 
      if (PHighCard > OHighCard) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PHighCard < OHighCard) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         cout << "Neither hand wins" << endl;
      }
   }
   else if (PRank == FourKind) {
      int PHigh4Kind, POther, OHigh4Kind, OOther;

      if (Pvals[0] == Pvals[1]) {
         PHigh4Kind = Pvals[0];
         POther = Pvals[4];
      }
      else {
         PHigh4Kind = Pvals[4];
         POther = Pvals[1];
      }
      if (Ovals[0] == Ovals[1]) {
         OHigh4Kind = Ovals[0];
         OOther = Ovals[4];
      }
      else {
         OHigh4Kind = Ovals[4];
         OOther = Ovals[1];
      }

      if (PHigh4Kind > OHigh4Kind) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PHigh4Kind < OHigh4Kind) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else if (POther > OOther) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (POther < OOther) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         cout << "Neither hand wins" << endl;
      }
   }
   else if (PRank == FullHouse) {
      int PHigh, PMid, PLow, OHigh, OMid, OLow;
      PHigh = Pvals[0];
      PMid = Pvals[2];
      PLow = Pvals[4];
      OHigh = Ovals[0];
      OMid = Ovals[2];
      OLow = Ovals[4];

      if (PMid > OMid) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PMid < OMid) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         // both players have the same 3Kind - so find the pair and compare
         if (PHigh == PMid) {
            if (PLow > OLow) {
               cout << "Player Wins!" << endl;
               numPlayerWins++;
            }
            else if (PLow < OLow) {
               cout << "Opponent Wins!" << endl;
               numOpponentWins++;
            }
            else {
               cout << "Neither hand wins" << endl;
            }
         }
         else {
            if (PHigh > OHigh) {
               cout << "Player Wins!" << endl;
               numPlayerWins++;
            }
            else if (PHigh < OHigh) {
               cout << "Opponent Wins!" << endl;
               numOpponentWins++;
            }
            else {
               cout << "Neither hand wins" << endl;
            }
         }
      }
   }
   else if (PRank == Flush) {
      bool winner = false;
      for (int i = 0; i < 5; i++) {
         if (Pvals[i] > Ovals[i]) {
            cout << "Player Wins!" << endl;
            numPlayerWins++;
            winner = true;
            break;
         }   
         else if (Pvals[i] < Ovals[i]) {
            cout << "Opponent Wins!" << endl;
            numOpponentWins++;
            winner = true;
            break;
         }
      }
      if (!winner) {
         cout << "Neither hand wins" << endl;
      }
   }
   else if (PRank == Straight) {
      if (Pvals[0] > Ovals[0]) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (Pvals[0] > Ovals[0]) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         cout << "Neither hand wins" << endl;
      }
   }
   else if (PRank == ThreeKind) {
      int PHighCard, PMidCard, PLowCard, OHighCard, OMidCard, OLowCard; 
      int PCard1, PCard2, OCard1, OCard2;

      PHighCard = Pvals[0];
      PMidCard = Pvals[2];
      PLowCard = Pvals[4];
      OHighCard = Ovals[0];
      OMidCard = Ovals[2];
      OLowCard = Ovals[4];

      if (PMidCard > OMidCard) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PMidCard < OMidCard) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         if (PHighCard == PMidCard) {
            PCard1 = Pvals[3];
            PCard2 = Pvals[4];
         }
         else if (PMidCard == PLowCard) {
            PCard1 = Pvals[0];
            PCard2 = Pvals[1];
         }
         else {
            PCard1 = Pvals[0];
            PCard2 = Pvals[4];
         }
         if (OHighCard == OMidCard) {
            OCard1 = Ovals[3];
            OCard2 = Ovals[4];
         }
         else if (OMidCard == OLowCard) {
            OCard1 = Ovals[0];
            OCard2 = Ovals[1];
         }
         else {
            OCard1 = Ovals[0];
            OCard2 = Ovals[4];
         }

         if (PCard1 > OCard1) {
            cout << "Player Wins!" << endl;
            numPlayerWins++;
         }
         else if (PCard1 < OCard1) {
            cout << "Opponent Wins!" << endl;
            numOpponentWins++;
         }
         else if (PCard2 > OCard2) {
            cout << "Player Wins!" << endl;
            numPlayerWins++;
         }
         else if (PCard2 < OCard2) {
            cout << "Opponent Wins!" << endl;
            numOpponentWins++;
         }
         else {
            cout << "Neither hand wins" << endl;
         }
      }
   }
   else if (PRank == TwoPair) {
      int PHighCard, PLowCard, POther, OHighCard, OLowCard, OOther;
      if ((Pvals[0] == Pvals[1]) && (Pvals[2] == Pvals[3])) {
         PHighCard = Pvals[0];
         PLowCard = Pvals[2];
         POther = Pvals[4];
      }
      else if ((Pvals[0] == Pvals[1]) && (Pvals[3] == Pvals[4])) {
         PHighCard = Pvals[0];
         PLowCard = Pvals[3];
         POther = Pvals[2];
      }
      else if ((Pvals[1] == Pvals[2]) && (Pvals[3] == Pvals[4])) {
         PHighCard = Pvals[1];
         PLowCard = Pvals[3];
         POther = Pvals[0];
      }

      if ((Ovals[0] == Ovals[1]) && (Ovals[2] == Ovals[3])) {
         OHighCard = Ovals[0];
         OLowCard = Ovals[2];
         OOther = Ovals[4];
      }
      else if ((Ovals[0] == Ovals[1]) && (Ovals[3] == Ovals[4])) {
         OHighCard = Ovals[0];
         OLowCard = Ovals[3];
         OOther = Ovals[2];
      }
      else if ((Ovals[1] == Ovals[2]) && (Ovals[3] == Ovals[4])) {
         OHighCard = Ovals[1];
         OLowCard = Ovals[3];
         OOther = Ovals[0];
      }

      if (PHighCard > OHighCard) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PHighCard < OHighCard) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      if (PLowCard > OLowCard) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PLowCard < OLowCard) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      if (POther > OOther) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (POther < OOther) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         cout << "Neither hand wins" << endl;
      }
   
   }
   else if (PRank == Pair) {
      int PPair, PHigh, PMid, PLow, OPair, OHigh, OMid, OLow;

      if (Pvals[0] == Pvals[1]) {
         PPair = Pvals[0];
         PHigh = Pvals[2];
         PMid = Pvals[3];
         PLow = Pvals[4];
      }
      else if (Pvals[1] == Pvals[2]) {
         PPair = Pvals[1];
         PHigh = Pvals[0];
         PMid = Pvals[3];
         PLow = Pvals[4];
      }
      else if (Pvals[2] == Pvals[3]) {
         PPair = Pvals[2];
         PHigh = Pvals[0];
         PMid = Pvals[1];
         PLow = Pvals[4];
      }
      else if (Pvals[3] == Pvals[4]) {
         PPair = Pvals[3];
         PHigh = Pvals[0];
         PMid = Pvals[1];
         PLow = Pvals[2];
      }

      if (Ovals[0] == Ovals[1]) {
         OPair = Ovals[0];
         OHigh = Ovals[2];
         OMid = Ovals[3];
         OLow = Ovals[4];
      }
      else if (Ovals[1] == Ovals[2]) {
         OPair = Ovals[1];
         OHigh = Ovals[0];
         OMid = Ovals[3];
         OLow = Ovals[4];
      }
      else if (Ovals[2] == Ovals[3]) {
         OPair = Ovals[2];
         OHigh = Ovals[0];
         OMid = Ovals[1];
         OLow = Ovals[4];
      }
      else if (Ovals[3] == Ovals[4]) {
         OPair = Ovals[3];
         OHigh = Ovals[0];
         OMid = Ovals[1];
         OLow = Ovals[2];
      }

      if (PPair > OPair) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PPair < OPair) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else if (PHigh > OHigh) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PHigh < OHigh) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else if (PMid > OMid) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PMid < OMid) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else if (PLow > OLow) {
         cout << "Player Wins!" << endl;
         numPlayerWins++;
      }
      else if (PLow < OLow) {
         cout << "Opponent Wins!" << endl;
         numOpponentWins++;
      }
      else {
         cout << "Neither hand wins" << endl;
      }
   }
   else if (PRank == High) {
      bool winner = false;
      for (int i = 0; i < 5; i++) {
         if (Pvals[i] > Ovals[i]) {
            cout << "Player Wins!" << endl;
            numPlayerWins++;
            winner = true;
            break;
         }   
         else if (Pvals[i] < Ovals[i]) {
            cout << "Opponent Wins!" << endl;
            numOpponentWins++;
            winner = true;
            break;
         }
      }
      if (!winner) {
         cout << "Neither hand wins" << endl;
      }
   }
}

void Game::PlayHand() {
   CRank PlayerRank, OpponentRank; 

   cout << "*****************************************************************" << endl;
   cout << "*                    Initial Deal of Cards                      *" << endl;
   cout << "*****************************************************************" << endl;
   initDeal();
   numHandsPlayed++;

   cout << "*****************************************************************" << endl;
   cout << "*                      Player's Turn                            *" << endl;
   cout << "*****************************************************************" << endl;
   PlayerTurn();
   PlayerRank = PlayerHand.ComputePokerRank();

   cout << "*****************************************************************" << endl;
   cout << "*                     Opponent's Turn                           *" << endl;
   cout << "*****************************************************************" << endl;
   OpponentTurn();
   OpponentRank = OpponentHand.ComputePokerRank();

   cout << "*****************************************************************" << endl;
   cout << "*                     The Showdown                              *" << endl;
   cout << "*****************************************************************" << endl;
   showHands();
   if (PlayerRank > OpponentRank) {
      cout << "Player Wins!" << endl;
      numPlayerWins++;
      return;
   }
   else if (PlayerRank < OpponentRank) {
      cout << "Opponent Wins!" << endl;
      numOpponentWins++;
      return;
   }
   else {
      // the ranks are equal (tied)
      // check the high cards in order to determine winner
      BreakTie();
   }
}

string Game::PromptPlayHand() {
   string answer;

   cout << "Do you wish to play a hand of 5 Card Draw? ";
   cin >> answer;
   transform(answer.begin(), answer.end(), answer.begin(), ::toupper);
   while ((answer != "YES") && (answer != "Y") && (answer != "NO") && (answer!= "N")) { 
      cout << "That is not a valid answer (Yes or No) - try again" << endl;
      cout << "Do you wish to play a hand of 5 Card Draw? ";
      cin >> answer;
      transform(answer.begin(), answer.end(), answer.begin(), ::toupper);
   }
   return answer;
}

void Game::ShowResults() {
   cout << "*****************************************************************" << endl;
   cout << "*****************************************************************" << endl;
   cout << "A total of " << numHandsPlayed << " hands were played" << endl;
   cout << "Opponent won " << numOpponentWins << " hands" << endl;
   cout << "Player won " << numPlayerWins << " hands" << endl;
}

void Game::PlayGame() {
   string answer;
   int shoesize;
   //initGame();
   shoestartsize = shoe.getSize();
   //shoe.Display();
   shoe.Shuffle();

   answer = PromptPlayHand();
   while ((answer == "YES") || (answer == "Y")) {
      shoesize = shoe.getSize();
      if ((shoesize < 52) || (shoesize < (0.3 * shoestartsize))) {
         shoe.ResetSize(shoestartsize);
         cout << endl;
         cout << "**** Reshuffling Deck(s) ****" << endl;
         cout << endl;
         shoe.Shuffle();
      }
      PlayHand();

      answer = PromptPlayHand();
   }
   ShowResults();
   cout << "---------------------------" << endl;
}

