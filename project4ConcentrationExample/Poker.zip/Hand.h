#ifndef HAND_H
#define HAND_H

#include "Card.h"

class Hand {
   int Pokersum;
   CRank Rank;

   int size;
   Card *cptr;

   bool checkRoyalFlush();
   bool checkStraightFlush();
   bool checkFourKind();
   bool checkFullHouse();
   bool checkFlush();
   bool checkStraight();
   bool checkThreeKind();
   bool checkTwoPair();
   bool checkPair();

   int PromptDiscard(int card_num);

public:
   void DisplayNoHole();
   void Display();
   void Append(Card C);
   void DeleteCard(int val);
   CRank ComputePokerRank();
   int  getSize();

   void sortHand();
   Card getCard(int pos);

   Hand();
   Hand(Hand &H);
   Hand & operator=(Hand &H);
   ~Hand();
};

#endif
