#ifndef GAME_H
#define GAME_H

#include "Card.h"
#include "Deck.h"
#include "Hand.h"

class Game {
   int shoestartsize;
   Deck shoe;
   Hand OpponentHand;
   Hand PlayerHand;
   int numHandsPlayed = 0;
   int numPlayerWins = 0;
   int numOpponentWins = 0;
    
   void OppDrawCards(int c1, int c2, int c3);
   void HandleFourKind();
   void HandleThreeKind();
   void HandleTwoPair();
   void HandlePair();
   void HandleHigh();

   int PromptDiscard(int card_num);
   void reverseSort(int &C1, int &C2, int &C3);
   void BreakTie();

public:
   Game();
   
   void initGame();

   void initDeal();
   void showHands();
   void showHandsNoHole();
   void PlayerTurn();
   void OpponentTurn();
   void PlayHand();
   string PromptPlayHand();
   void ShowResults();
   void PlayGame();

};

   
#endif   
